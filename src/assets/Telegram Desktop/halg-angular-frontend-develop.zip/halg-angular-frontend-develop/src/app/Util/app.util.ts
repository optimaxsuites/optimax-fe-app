import { Component, Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})

export class UtilService {

  constructor() { }

  
}
